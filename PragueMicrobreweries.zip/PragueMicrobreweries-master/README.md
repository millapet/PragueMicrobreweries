# PragueMicrobreweries
A simple map of microbreweries in Prague made using Leaflet. 
Microbreweries' information was originally part of a school project at CTU in Prague, Faculty of Civil Engineering, 2016. 